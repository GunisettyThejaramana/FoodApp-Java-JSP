package model;

public class CartModel {
    private int cartid;
    private int userid;
    private int menuid;
    private int quantity;
    private float item_total;

    // Default Constructor
    public CartModel() {
    }

    // Parameterized Constructor
    public CartModel(int cartid, int userid, int menuid, int quantity, float item_total) {
        this.cartid = cartid;
        this.userid = userid;
        this.menuid = menuid;
        this.quantity = quantity;
        this.item_total = item_total;
    }

    // Another Constructor without cartid (for insert use)
    public CartModel(int userid, int menuid, int quantity, float item_total) {
        this.userid = userid;
        this.menuid = menuid;
        this.quantity = quantity;
        this.item_total = item_total;
    }

    // Getters and Setters
    public int getCartid() {
        return cartid;
    }

    public void setCartid(int cartid) {
        this.cartid = cartid;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public int getMenuid() {
        return menuid;
    }

    public void setMenuid(int menuid) {
        this.menuid = menuid;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public float getItem_total() {
        return item_total;
    }

    public void setItem_total(float item_total) {
        this.item_total = item_total;
    }

    // toString method
    @Override
    public String toString() {
        return "CartModel{" +
                "cartid=" + cartid +
                ", userid=" + userid +
                ", menuid=" + menuid +
                ", quantity=" + quantity +
                ", item_total=" + item_total +
                '}';
    }
}
