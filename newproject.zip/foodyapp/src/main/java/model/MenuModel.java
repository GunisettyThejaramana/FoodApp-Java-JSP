package model;

public class MenuModel {
	
	    private int menuid;
	    private int restaurantid;
	    private String menu_name;
	    private String description;
	    private int price;
	    private boolean is_available;
	    private String image_path;
	    private int quantity;  


	    public MenuModel() {}

	    public MenuModel(int menuid, int restaurantid, String menu_name, String description,
	                     int price, boolean is_available, String image_path) {
	        this.menuid = menuid;
	        this.restaurantid = restaurantid;
	        this.menu_name = menu_name;
	        this.description = description;
	        this.price = price;
	        this.is_available = is_available;
	        this.image_path = image_path;
	    }

	    public int getMenuid() { return menuid; }
	    public void setMenuid(int menuid) { this.menuid = menuid; }

	    public int getRestaurantid() { return restaurantid; }
	    public void setRestaurantid(int restaurantid) { this.restaurantid = restaurantid; }

	    public String getMenu_name() { return menu_name; }
	    public void setMenu_name(String menu_name) { this.menu_name = menu_name; }

	    public String getDescription() { return description; }
	    public void setDescription(String description) { this.description = description; }

	    public int getPrice() { return price; }
	    public void setPrice(int price) { this.price = price; }

	    public boolean isIs_available() { return is_available; }
	    public void setIs_available(boolean is_available) { this.is_available = is_available; }

	    public String getImage_path() { return image_path; }
	    public void setImage_path(String image_path) { this.image_path = image_path; }
	    
	    
	    public int getQuantity() {
	        return quantity;
	    }

	    public void setQuantity(int quantity) {
	        this.quantity = quantity;
	    }


	    @Override
	    public String toString() {
	        return "MenuModel [menuid=" + menuid + ", restaurantid=" + restaurantid +
	               ", menu_name=" + menu_name + ", description=" + description +
	               ", price=" + price + ", is_available=" + is_available +
	               ", image_path=" + image_path + ", quantity=" + quantity +"]";
	    }
	}


