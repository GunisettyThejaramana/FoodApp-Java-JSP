package model;

public class RestaurantModel {

	
	
	
	
	
	
	
	
	    private int restaurantid;
	    private String restaurantname;
	    private String cuisine_type;
	    private float rating;
	    private int delivery_time;
	    private String image_path;

	    public RestaurantModel() {}

	    public RestaurantModel(int restaurantid, String restaurantname, String cuisine_type,
	                           float rating, int delivery_time, String image_path) {
	        this.restaurantid = restaurantid;
	        this.restaurantname = restaurantname;
	        this.cuisine_type = cuisine_type;
	        this.rating = rating;
	        this.delivery_time = delivery_time;
	        this.image_path = image_path;
	    }

	    public int getRestaurantid() { return restaurantid; }
	    public void setRestaurantid(int restaurantid) { this.restaurantid = restaurantid; }

	    public String getRestaurantname() { return restaurantname; }
	    public void setRestaurantname(String restaurantname) { this.restaurantname = restaurantname; }

	    public String getCuisine_type() { return cuisine_type; }
	    public void setCuisine_type(String cuisine_type) { this.cuisine_type = cuisine_type; }

	    public float getRating() { return rating; }
	    public void setRating(float rating) { this.rating = rating; }

	    public int getDelivery_time() { return delivery_time; }
	    public void setDelivery_time(int delivery_time) { this.delivery_time = delivery_time; }

	    public String getImage_path() { return image_path; }
	    public void setImage_path(String image_path) { this.image_path = image_path; }

	    @Override
	    public String toString() {
	        return "RestaurantModel [restaurantid=" + restaurantid + ", restaurantname=" + restaurantname +
	               ", cuisine_type=" + cuisine_type + ", rating=" + rating +
	               ", delivery_time=" + delivery_time + ", image_path=" + image_path + "]";
	    }
	}
