package model;

public class OrdersModel {
	
	
	
	
	
	
	
	
	    private int orderid;
	    private int userid;
	    private int restaurantid;
	    private float total_amount;
	    private String status;
	    private String payment_mode;

	    public OrdersModel() {}

	    public OrdersModel(int orderid, int userid, int restaurantid, float total_amount, String status, String payment_mode) {
	        this.orderid = orderid;
	        this.userid = userid;
	        this.restaurantid = restaurantid;
	        this.total_amount = total_amount;
	        this.status = status;
	        this.payment_mode = payment_mode;
	    }

	    public int getOrderid() { return orderid; }
	    public void setOrderid(int orderid) { this.orderid = orderid; }

	    public int getUserid() { return userid; }
	    public void setUserid(int userid) { this.userid = userid; }

	    public int getRestaurantid() { return restaurantid; }
	    public void setRestaurantid(int restaurantid) { this.restaurantid = restaurantid; }

	    public float getTotal_amount() { return total_amount; }
	    public void setTotal_amount(float total_amount) { this.total_amount = total_amount; }

	    public String getStatus() { return status; }
	    public void setStatus(String status) { this.status = status; }

	    public String getPayment_mode() { return payment_mode; }
	    public void setPayment_mode(String payment_mode) { this.payment_mode = payment_mode; }

	    @Override
	    public String toString() {
	        return "OrdersModel [orderid=" + orderid + ", userid=" + userid + ", restaurantid=" + restaurantid +
	               ", total_amount=" + total_amount + ", status=" + status + ", payment_mode=" + payment_mode + "]";
	    }
	}

	
	
	
	


