package dao.interfaces;

import java.util.List;
import model.OrderItemsModel;

public interface OrderItemsDAO {
    boolean insert(OrderItemsModel item);
    List<OrderItemsModel> fetchAll();
    OrderItemsModel fetchOne(int orderitemid);
    boolean update(OrderItemsModel item);
    boolean delete(int orderitemid);
}
