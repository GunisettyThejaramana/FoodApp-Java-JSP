package dao.interfaces;



import java.util.List;
import model.RestaurantModel;
public interface RestaurantDAO {
	
	
	
	
	
	
	    boolean insert(RestaurantModel restaurant);
	    List<RestaurantModel> fetchAll();
	    RestaurantModel fetchOne(int restaurantid);
	    boolean update(RestaurantModel restaurant);
	    boolean delete(int restaurantid);
	}
