package dao.interfaces;

import model.CartModel;
import java.util.List;

public interface CartDAO {
    boolean insert(CartModel cart);
    List<CartModel> fetchByUser(int userid);
    boolean deleteByUser(int userid);
}
