package dao.interfaces;

import java.util.List;
import model.OrdersModel;

public interface OrdersDAO {
    boolean insert(OrdersModel order);
    List<OrdersModel> fetchAll();
    OrdersModel fetchOne(int orderid);
    boolean update(OrdersModel order);
    boolean delete(int orderid);
}
