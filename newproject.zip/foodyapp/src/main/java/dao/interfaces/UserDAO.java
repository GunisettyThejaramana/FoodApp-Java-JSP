package dao.interfaces;


import java.util.List;
import model.UserModel;

public interface UserDAO {
	
	
	    boolean insert(UserModel user);
	    List<UserModel> fetchAll();
	    UserModel fetchOne(int userid);
	    boolean update(UserModel user);
	    boolean delete(int userid);
	}

	
	


