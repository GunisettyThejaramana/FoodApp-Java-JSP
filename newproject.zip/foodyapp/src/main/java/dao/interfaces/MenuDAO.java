package dao.interfaces;

import java.util.List;
import model.MenuModel;

public interface MenuDAO {
    boolean insert(MenuModel menu);
    List<MenuModel> fetchAll();
    MenuModel fetchOne(int menuid);
    boolean update(MenuModel menu);
    boolean delete(int menuid);
}
