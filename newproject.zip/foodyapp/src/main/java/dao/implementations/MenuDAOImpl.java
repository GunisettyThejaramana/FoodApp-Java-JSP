package dao.implementations;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import dao.interfaces.MenuDAO;
import model.MenuModel;
import util.DBConnection;

public class MenuDAOImpl implements MenuDAO {

    @Override
    public boolean insert(MenuModel menu) {
        String query = "INSERT INTO menu (menuid, restaurantid, menu_name, description, price, is_available, image_path) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, menu.getMenuid());
            ps.setInt(2, menu.getRestaurantid());
            ps.setString(3, menu.getMenu_name());
            ps.setString(4, menu.getDescription());
            ps.setInt(5, menu.getPrice());
            ps.setBoolean(6, menu.isIs_available());
            ps.setString(7, menu.getImage_path());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public List<MenuModel> fetchAll() {
        List<MenuModel> menus = new ArrayList<>();
        String query = "SELECT * FROM menu";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                MenuModel menu = new MenuModel(
                    rs.getInt("menuid"),
                    rs.getInt("restaurantid"),
                    rs.getString("menu_name"),
                    rs.getString("description"),
                    rs.getInt("price"),
                    rs.getBoolean("is_available"),
                    rs.getString("image_path")
                );
                menus.add(menu);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return menus;
    }

    @Override
    public MenuModel fetchOne(int menuid) {
        String query = "SELECT * FROM menu WHERE menuid = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, menuid);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new MenuModel(
                    rs.getInt("menuid"),
                    rs.getInt("restaurantid"),
                    rs.getString("menu_name"),
                    rs.getString("description"),
                    rs.getInt("price"),
                    rs.getBoolean("is_available"),
                    rs.getString("image_path")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean update(MenuModel menu) {
        String query = "UPDATE menu SET restaurantid = ?, menu_name = ?, description = ?, price = ?, is_available = ?, image_path = ? WHERE menuid = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, menu.getRestaurantid());
            ps.setString(2, menu.getMenu_name());
            ps.setString(3, menu.getDescription());
            ps.setInt(4, menu.getPrice());
            ps.setBoolean(5, menu.isIs_available());
            ps.setString(6, menu.getImage_path());
            ps.setInt(7, menu.getMenuid());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean delete(int menuid) {
        String query = "DELETE FROM menu WHERE menuid = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, menuid);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
