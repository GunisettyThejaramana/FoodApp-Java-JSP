package dao.implementations;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import dao.interfaces.RestaurantDAO;
import model.RestaurantModel;
import util.DBConnection;

public class RestaurantDAOImpl implements RestaurantDAO {

    @Override
    public boolean insert(RestaurantModel restaurant) {
        String query = "INSERT INTO restaurants (restaurantid, restaurantname, cuisine_type, rating, delivery_time, image_path) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, restaurant.getRestaurantid());
            ps.setString(2, restaurant.getRestaurantname());
            ps.setString(3, restaurant.getCuisine_type());
            ps.setFloat(4, restaurant.getRating());
            ps.setInt(5, restaurant.getDelivery_time());
            ps.setString(6, restaurant.getImage_path());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public List<RestaurantModel> fetchAll() {
        List<RestaurantModel> restaurants = new ArrayList<>();
        String query = "SELECT * FROM restaurants";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                RestaurantModel restaurant = new RestaurantModel(
                    rs.getInt("restaurantid"),
                    rs.getString("restaurantname"),
                    rs.getString("cuisine_type"),
                    rs.getFloat("rating"),
                    rs.getInt("delivery_time"),
                    rs.getString("image_path")
                );
                restaurants.add(restaurant);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return restaurants;
    }

    @Override
    public RestaurantModel fetchOne(int restaurantid) {
        String query = "SELECT * FROM restaurants WHERE restaurantid = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, restaurantid);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new RestaurantModel(
                    rs.getInt("restaurantid"),
                    rs.getString("restaurantname"),
                    rs.getString("cuisine_type"),
                    rs.getFloat("rating"),
                    rs.getInt("delivery_time"),
                    rs.getString("image_path")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean update(RestaurantModel restaurant) {
        String query = "UPDATE restaurants SET restaurantname = ?, cuisine_type = ?, rating = ?, delivery_time = ?, image_path = ? WHERE restaurantid = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, restaurant.getRestaurantname());
            ps.setString(2, restaurant.getCuisine_type());
            ps.setFloat(3, restaurant.getRating());
            ps.setInt(4, restaurant.getDelivery_time());
            ps.setString(5, restaurant.getImage_path());
            ps.setInt(6, restaurant.getRestaurantid());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean delete(int restaurantid) {
        String query = "DELETE FROM restaurants WHERE restaurantid = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, restaurantid);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
