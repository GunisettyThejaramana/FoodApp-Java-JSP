package dao.implementations;

import dao.interfaces.CartDAO;
import model.CartModel;
import util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CartDAOImpl implements CartDAO {

    @Override
    public boolean insert(CartModel cart) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO cart (userid, menuid, quantity, item_total) VALUES (?, ?, ?, ?)")) {
            ps.setInt(1, cart.getUserid());
            ps.setInt(2, cart.getMenuid());
            ps.setInt(3, cart.getQuantity());
            ps.setFloat(4, cart.getItem_total());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<CartModel> fetchByUser(int userid) {
        List<CartModel> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM cart WHERE userid = ?")) {
            ps.setInt(1, userid);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                CartModel c = new CartModel();
                c.setCartid(rs.getInt("cartid"));
                c.setUserid(rs.getInt("userid"));
                c.setMenuid(rs.getInt("menuid"));
                c.setQuantity(rs.getInt("quantity"));
                c.setItem_total(rs.getFloat("item_total"));
                list.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public boolean deleteByUser(int userid) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM cart WHERE userid = ?")) {
            ps.setInt(1, userid);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
