package dao.implementations;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import dao.interfaces.OrdersDAO;
import model.OrdersModel;
import util.DBConnection;

public class OrdersDAOImpl implements OrdersDAO {

    @Override
    public boolean insert(OrdersModel order) {
        String query = "INSERT INTO orders (orderid, userid, restaurantid, total_amount, status, payment_mode) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, order.getOrderid());
            ps.setInt(2, order.getUserid());
            ps.setInt(3, order.getRestaurantid());
            ps.setFloat(4, order.getTotal_amount());
            ps.setString(5, order.getStatus());
            ps.setString(6, order.getPayment_mode());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public List<OrdersModel> fetchAll() {
        List<OrdersModel> orders = new ArrayList<>();
        String query = "SELECT * FROM orders";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                OrdersModel order = new OrdersModel(
                    rs.getInt("orderid"),
                    rs.getInt("userid"),
                    rs.getInt("restaurantid"),
                    rs.getFloat("total_amount"),
                    rs.getString("status"),
                    rs.getString("payment_mode")
                );
                orders.add(order);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return orders;
    }

    @Override
    public OrdersModel fetchOne(int orderid) {
        String query = "SELECT * FROM orders WHERE orderid = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, orderid);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new OrdersModel(
                    rs.getInt("orderid"),
                    rs.getInt("userid"),
                    rs.getInt("restaurantid"),
                    rs.getFloat("total_amount"),
                    rs.getString("status"),
                    rs.getString("payment_mode")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean update(OrdersModel order) {
        String query = "UPDATE orders SET userid = ?, restaurantid = ?, total_amount = ?, status = ?, payment_mode = ? WHERE orderid = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, order.getUserid());
            ps.setInt(2, order.getRestaurantid());
            ps.setFloat(3, order.getTotal_amount());
            ps.setString(4, order.getStatus());
            ps.setString(5, order.getPayment_mode());
            ps.setInt(6, order.getOrderid());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean delete(int orderid) {
        String query = "DELETE FROM orders WHERE orderid = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, orderid);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
