package dao.implementations;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import dao.interfaces.OrderItemsDAO;
import model.OrderItemsModel;
import util.DBConnection;

public class OrderItemsDAOImpl implements OrderItemsDAO {

    @Override
    public boolean insert(OrderItemsModel item) {
        String query = "INSERT INTO order_items (orderitemid, orderid, menuid, quantity, item_total) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, item.getOrderitemid());
            ps.setInt(2, item.getOrderid());
            ps.setInt(3, item.getMenuid());
            ps.setInt(4, item.getQuantity());
            ps.setFloat(5, item.getItem_total());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public List<OrderItemsModel> fetchAll() {
        List<OrderItemsModel> items = new ArrayList<>();
        String query = "SELECT * FROM order_items";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                OrderItemsModel item = new OrderItemsModel(
                    rs.getInt("orderitemid"),
                    rs.getInt("orderid"),
                    rs.getInt("menuid"),
                    rs.getInt("quantity"),
                    rs.getFloat("item_total")
                );
                items.add(item);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return items;
    }

    @Override
    public OrderItemsModel fetchOne(int orderitemid) {
        String query = "SELECT * FROM order_items WHERE orderitemid = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, orderitemid);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new OrderItemsModel(
                    rs.getInt("orderitemid"),
                    rs.getInt("orderid"),
                    rs.getInt("menuid"),
                    rs.getInt("quantity"),
                    rs.getFloat("item_total")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean update(OrderItemsModel item) {
        String query = "UPDATE order_items SET orderid = ?, menuid = ?, quantity = ?, item_total = ? WHERE orderitemid = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, item.getOrderid());
            ps.setInt(2, item.getMenuid());
            ps.setInt(3, item.getQuantity());
            ps.setFloat(4, item.getItem_total());
            ps.setInt(5, item.getOrderitemid());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean delete(int orderitemid) {
        String query = "DELETE FROM order_items WHERE orderitemid = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, orderitemid);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
