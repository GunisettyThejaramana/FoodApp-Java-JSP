package controller;

import java.io.IOException;
import java.util.*;


import dao.implementations.OrdersDAOImpl;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import dao.implementations.OrderItemsDAOImpl;
import model.MenuModel;
import model.OrdersModel;
import model.OrderItemsModel;

@WebServlet("/checkout")
public class CheckoutServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        List<MenuModel> cart = (List<MenuModel>) session.getAttribute("cart");
        int userid = (int) session.getAttribute("userid");

        if (cart == null || cart.isEmpty()) {
            response.sendRedirect("cart.jsp");
            return;
        }

        // Calculate total amount
        float totalAmount = 0;
        for (MenuModel item : cart) {
            totalAmount += item.getPrice() * item.getQuantity();
        }

        // Generate dummy order ID (in real project, use auto-increment or sequence)
        int orderid = new Random().nextInt(100000); // not recommended for production
        int restaurantid = cart.get(0).getRestaurantid();
        String paymentMode = request.getParameter("payment_mode");
        String status = "Placed";

        OrdersModel order = new OrdersModel(orderid, userid, restaurantid, totalAmount, status, paymentMode);
        OrdersDAOImpl orderDAO = new OrdersDAOImpl();
        boolean orderSuccess = orderDAO.insert(order);

        if (orderSuccess) {
            OrderItemsDAOImpl itemsDAO = new OrderItemsDAOImpl();

            for (MenuModel item : cart) {
                int itemTotal = item.getPrice() * item.getQuantity();
                int orderItemId = new Random().nextInt(100000);
                OrderItemsModel itemModel = new OrderItemsModel(orderItemId, orderid, item.getMenuid(), item.getQuantity(), itemTotal);
                itemsDAO.insert(itemModel);
            }

            session.removeAttribute("cart"); // Clear cart
            request.setAttribute("message", "Order placed successfully!");
            RequestDispatcher rd = request.getRequestDispatcher("orderSuccess.jsp");
            rd.forward(request, response);
        } else {
            request.setAttribute("error", "Order failed!");
            RequestDispatcher rd = request.getRequestDispatcher("checkout.jsp");
            rd.forward(request, response);
        }
    }
}
