package controller;

import dao.implementations.MenuDAOImpl;
import model.MenuModel;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@WebServlet("/menu")
public class MenuServlet extends HttpServlet {

    private MenuDAOImpl menuDAO;

    @Override
    public void init() throws ServletException {
        menuDAO = new MenuDAOImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String restaurantIdParam = request.getParameter("restaurantid");

        if (restaurantIdParam != null && !restaurantIdParam.isEmpty()) {
            try {
                int restaurantId = Integer.parseInt(restaurantIdParam);

                List<MenuModel> allMenus = menuDAO.fetchAll();

                // ✅ Use Collectors.toList() for Java 8+ compatibility
                List<MenuModel> filteredMenus = allMenus.stream()
                        .filter(menu -> menu.getRestaurantid() == restaurantId)
                        .collect(Collectors.toList());

                request.setAttribute("menus", filteredMenus);
                request.setAttribute("restaurantid", restaurantId);

                request.getRequestDispatcher("jsp/menu.jsp").forward(request, response);

            } catch (NumberFormatException e) {
                e.printStackTrace();
                response.sendRedirect("jsp/error.jsp");
            }
        } else {
            response.sendRedirect("jsp/error.jsp");
        }
    }
}
