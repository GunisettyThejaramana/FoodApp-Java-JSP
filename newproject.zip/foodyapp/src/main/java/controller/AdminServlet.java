package controller;

import java.io.IOException;
import java.util.List;


import dao.implementations.UserDAOImpl;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import dao.implementations.OrdersDAOImpl;
import model.UserModel;
import model.OrdersModel;

@WebServlet("/admin")
public class AdminServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        UserDAOImpl userDAO = new UserDAOImpl();
        OrdersDAOImpl ordersDAO = new OrdersDAOImpl();

        List<UserModel> users = userDAO.fetchAll();
        List<OrdersModel> orders = ordersDAO.fetchAll();

        request.setAttribute("users", users);
        request.setAttribute("orders", orders);

        RequestDispatcher rd = request.getRequestDispatcher("adminDashboard.jsp");
        rd.forward(request, response);
    }
}
