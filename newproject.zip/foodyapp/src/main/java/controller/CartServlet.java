package controller;

import java.io.IOException;
import java.util.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.MenuModel;

@WebServlet("/cart")
public class CartServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int menuid = Integer.parseInt(request.getParameter("menuid"));
        String name = request.getParameter("name");
        int price = Integer.parseInt(request.getParameter("price"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        HttpSession session = request.getSession();
        List<MenuModel> cart = (List<MenuModel>) session.getAttribute("cart");

        if (cart == null) {
            cart = new ArrayList<>();
        }

        boolean exists = false;
        for (MenuModel item : cart) {
            if (item.getMenuid() == menuid) {
                item.setQuantity(item.getQuantity() + quantity);
                exists = true;
                break;
            }
        }

        if (!exists) {
            MenuModel menu = new MenuModel();
            menu.setMenuid(menuid);
            menu.setMenu_name(name);
            menu.setPrice(price);
            menu.setQuantity(quantity);
            cart.add(menu);
        }

        session.setAttribute("cart", cart);
        response.sendRedirect("cart.jsp");
    }
}
