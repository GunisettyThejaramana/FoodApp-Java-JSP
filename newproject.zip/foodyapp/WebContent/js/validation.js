function validateForm() {
  let username = document.forms["regForm"]["username"].value;
  let email = document.forms["regForm"]["email"].value;

  if (username == "" || email == "") {
    alert("All fields must be filled out");
    return false;
  }
}
