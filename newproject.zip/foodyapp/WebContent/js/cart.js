function removeFromCart(itemId) {
  document.getElementById("item-" + itemId).remove();
  // update total (add your logic)
}
